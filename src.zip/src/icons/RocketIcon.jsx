import { ReactComponent as RocketSVG } from '../assets/icons/rocket.svg';

export default function RocketIcon(props) {
  return <RocketSVG {...props} />;
}
