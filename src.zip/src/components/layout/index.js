export { default as Navbar } from './Navbar';
export { default as Footer } from './Footer';

// src/components/ui/index.js
import Button from '../ui/Button';