const Navbar = () => {
  return <nav>Navbar Content</nav>;
};

export default Navbar;
