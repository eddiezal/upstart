// Remove Button import and fix Navbar export
export { default as Navbar } from './Navbar';  // Ensure case matches
export { default as Footer } from './Footer';
// src/components/ui/index.js
export { default as Button } from '../ui/Button';
