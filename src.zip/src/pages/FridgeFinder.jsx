const FridgeFinder = () => {
  return <div>Fridge Finder Content</div>;
};

export default FridgeFinder;
