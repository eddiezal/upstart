import { ReactComponent as HandshakeSVG } from '../assets/icons/handshake.svg';

export default function HandshakeIcon(props) {
  return <HandshakeSVG {...props} />;
}