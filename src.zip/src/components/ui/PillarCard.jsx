import React from 'react';

const PillarCard = ({ Icon, title, description }) => {
  return (
    <div className="bg-cream p-6 rounded-xl shadow-lg text-center">
      <div className="flex justify-center mb-4">
        <Icon className="w-12 h-12 text-forest-green" />
      </div>
      <h3 className="text-h3 font-poppins font-bold text-forest-green mb-2">
        {title}
      </h3>
      <p className="text-bodyRegular font-roboto text-warm-sand">
        {description}
      </p>
    </div>
  );
};

export default PillarCard;
