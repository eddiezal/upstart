// src/components/layout/index.js
export { default as Navbar } from './Navbar';
export { default as Footer } from './Footer';