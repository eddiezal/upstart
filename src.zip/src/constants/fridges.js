export const FRIDGES = [
    { id: 1, location: 'San Diego', available: true },
    { id: 2, location: 'Los Angeles', available: false },
  ];
  