const phrases = [
  "Farms to Families.",
  "Community-Centered Growth.",
  "Empowering Local Heroes.",
  "Change Starts Here.",
  "Celebrate Local Farmers.",
  "Revive Local Economies.",
  "Think Local. Dream Big.",
  "Act Now. Grow Together.",
  "Live for Tomorrow."
];

export default phrases;
