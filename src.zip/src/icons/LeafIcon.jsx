import { ReactComponent as LeafSVG } from '../assets/icons/leaf.svg';

export default function LeafIcon(props) {
  return <LeafSVG {...props} />;
}